#!/bin/bash

for (( a = 5; a > 0; a-- ))
do
	for(( b = 1; b <= a; b++ ))
	do
		echo -n "*"
		done
		echo ""
done
